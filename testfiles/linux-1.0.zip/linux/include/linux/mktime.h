#ifndef _LINUX_MKTIME_H
#define _LINUX_MKTIME_H

struct mktime {
	int sec;
	int min;
	int hour;
	int day;
	int mon;
	int year;
};

#endif
