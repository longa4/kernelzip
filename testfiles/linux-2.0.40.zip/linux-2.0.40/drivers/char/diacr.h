#ifndef _DIACR_H
#define _DIACR_H
#include <linux/kd.h>

extern struct kbdiacr accent_table[];
extern unsigned int accent_table_size;

#endif /* _DIACR_H */
