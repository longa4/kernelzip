Tools that manage md devices can be found at sweet-smoke.ufr-info-p7.ibp.fr
in public/Linux/md035.tar.gz.

	Marc ZYNGIER <zyngier@ufr-info-p7.ibp.fr>
