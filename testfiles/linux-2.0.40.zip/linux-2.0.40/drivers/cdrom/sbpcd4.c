/*
 * duplication of sbpcd.c for multiple interfaces
 */
#define SBPCD_ISSUE 4
#include "sbpcd.c"
