/*
 * duplication of sbpcd.c for multiple interfaces
 */
#define SBPCD_ISSUE 3
#include "sbpcd.c"
