/*
 * List of Linux/MIPS syscalls.
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (C) 1995 by Ralf Baechle
 */

/*
 * This file is being included twice - once to build a list of all
 * syscalls and once to build a table of how many arguments each syscall
 * accepts.  Syscalls that receive a pointer to the saved registers are
 * marked as having zero arguments.
 *
 * The binary compatibility calls are still missing in this list.
 */
SYS(sys_syscall, 7)				/* 4000 */
SYS(sys_exit, 1)
SYS(sys_fork, 0)
SYS(sys_read, 3)
SYS(sys_write, 3)
SYS(sys_open, 3)				/* 4005 */
SYS(sys_close, 3)
SYS(sys_waitpid, 3)
SYS(sys_creat, 2)
SYS(sys_link, 2)
SYS(sys_unlink, 1)				/* 4010 */
SYS(sys_execve, 0)
SYS(sys_chdir, 1)
SYS(sys_time, 1)
SYS(sys_mknod, 3)
SYS(sys_chmod, 2)				/* 4015 */
SYS(sys_chown, 3)
SYS(sys_break, 0)
SYS(sys_stat, 2)
SYS(sys_lseek, 3)
SYS(sys_getpid, 0)				/* 4020 */
SYS(sys_mount, 5)
SYS(sys_umount, 1)
SYS(sys_setuid, 1)
SYS(sys_getuid, 0)
SYS(sys_stime, 1)				/* 4025 */
SYS(sys_ptrace, 4)
SYS(sys_alarm, 1)
SYS(sys_fstat, 2)
SYS(sys_pause, 0)
SYS(sys_utime, 2)				/* 4030 */
SYS(sys_stty, 0)
SYS(sys_gtty, 0)
SYS(sys_access, 2)
SYS(sys_nice, 1)
SYS(sys_ftime, 0)				/* 4035 */
SYS(sys_sync, 0)
SYS(sys_kill, 2)
SYS(sys_rename, 2)
SYS(sys_mkdir, 2)
SYS(sys_rmdir, 1)				/* 4040 */
SYS(sys_dup, 1)
SYS(sys_pipe, 0)
SYS(sys_times, 1)
SYS(sys_prof, 0)
SYS(sys_brk, 1)					/* 4045 */
SYS(sys_setgid, 1)
SYS(sys_getgid, 0)
SYS(sys_signal, 2)
SYS(sys_geteuid, 0)
SYS(sys_getegid, 0)				/* 4050 */
SYS(sys_acct, 0)
SYS(sys_phys, 0)
SYS(sys_lock, 0)
SYS(sys_ioctl, 3)
SYS(sys_fcntl, 3)				/* 4055 */
SYS(sys_mpx, 2)
SYS(sys_setpgid, 2)
SYS(sys_ulimit, 0)
SYS(sys_olduname, 1)
SYS(sys_umask, 1)				/* 4060 */
SYS(sys_chroot, 1)
SYS(sys_ustat, 2)
SYS(sys_dup2, 2)
SYS(sys_getppid, 0)
SYS(sys_getpgrp, 0)				/* 4065 */
SYS(sys_setsid, 0)
SYS(sys_sigaction, 3)
SYS(sys_sgetmask, 0)
SYS(sys_ssetmask, 1)
SYS(sys_setreuid, 2)				/* 4070 */
SYS(sys_setregid, 2)
SYS(sys_sigsuspend, 3)
SYS(sys_sigpending, 1)
SYS(sys_sethostname, 2)
SYS(sys_setrlimit, 2)				/* 4075 */
SYS(sys_getrlimit, 2)
SYS(sys_getrusage, 2)
SYS(sys_gettimeofday, 2)
SYS(sys_settimeofday, 2)
SYS(sys_getgroups, 2)				/* 4080 */
SYS(sys_setgroups, 2)
SYS(sys_ni_syscall, 0) /* old_select */
SYS(sys_symlink, 2)
SYS(sys_lstat, 2)
SYS(sys_readlink, 3)				/* 4085 */
SYS(sys_uselib, 1)
SYS(sys_swapon, 2)
SYS(sys_reboot, 3)
SYS(old_readdir, 3)
SYS(sys_mmap, 6)				/* 4090 */
SYS(sys_munmap, 2)
SYS(sys_truncate, 2)
SYS(sys_ftruncate, 2)
SYS(sys_fchmod, 2)
SYS(sys_fchown, 3)				/* 4095 */
SYS(sys_getpriority, 2)
SYS(sys_setpriority, 3)
SYS(sys_profil, 0)
SYS(sys_statfs, 2)
SYS(sys_fstatfs, 2)				/* 4100 */
SYS(sys_ioperm, 3)
SYS(sys_socketcall, 2)
SYS(sys_syslog, 3)
SYS(sys_setitimer, 3)
SYS(sys_getitimer, 2)				/* 4105 */
SYS(sys_newstat, 2)
SYS(sys_newlstat, 2)
SYS(sys_newfstat, 2)
SYS(sys_uname, 1)
SYS(sys_iopl, 0)	/* Well, actually 17 args ... */				/* 4110 */
SYS(sys_vhangup, 0)
SYS(sys_idle, 0)
SYS(sys_vm86, 1)
SYS(sys_wait4, 4)
SYS(sys_swapoff, 1)				/* 4115 */
SYS(sys_sysinfo, 1)
SYS(sys_ipc, 6)
SYS(sys_fsync, 1)
SYS(sys_sigreturn, 0)
SYS(sys_clone, 0)				/* 4120 */
SYS(sys_setdomainname, 2)
SYS(sys_newuname, 1)
SYS(sys_ni_syscall, 0) /* sys_modify_ldt */
SYS(sys_adjtimex, 1)
SYS(sys_mprotect, 3)				/* 4125 */
SYS(sys_sigprocmask, 3)
SYS(sys_create_module, 2)
SYS(sys_init_module, 5)
SYS(sys_delete_module, 1)
SYS(sys_get_kernel_syms, 1)			/* 4130 */
SYS(sys_quotactl, 0)
SYS(sys_getpgid, 1)
SYS(sys_fchdir, 1)
SYS(sys_bdflush, 2)
SYS(sys_sysfs, 3)				/* 4135 */
SYS(sys_personality, 1)
SYS(sys_ni_syscall, 0) /* for afs_syscall */
SYS(sys_setfsuid, 1)
SYS(sys_setfsgid, 1)
SYS(sys_llseek, 5)				/* 4140 */
SYS(sys_getdents, 3)
SYS(sys_select, 5)
SYS(sys_flock, 2)
SYS(sys_msync, 3)
SYS(sys_readv, 3)				/* 4145 */
SYS(sys_writev, 3)
SYS(sys_cacheflush, 3)
SYS(sys_cachectl, 3)
SYS(sys_sysmips, 4)
SYS(sys_setup, 0)				/* 4150 */
SYS(sys_getsid, 1)
SYS(sys_ni_syscall, 0)
SYS(sys_ni_syscall, 0)
SYS(sys_mlock, 2)
SYS(sys_munlock, 2)				/* 4155 */
SYS(sys_mlockall, 1)
SYS(sys_munlockall, 0)
