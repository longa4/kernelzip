/* $Id: empirical.h,v 1.2 1996/04/23 01:53:42 davem Exp $
 * empirical.h:  Nasty hacks....
 *
 * Copyright (C) 1995 David S. Miller (davem@caip.rutgers.edu)
 */

#define DEF_BOGO     25

